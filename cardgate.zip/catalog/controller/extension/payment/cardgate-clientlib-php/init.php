<?php

require_once dirname( __FILE__ ) . '/src/Autoloader.php';

cardgate\api\Autoloader::register();